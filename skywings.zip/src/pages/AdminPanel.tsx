import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { auth, db } from '../firebase';
import { collection, query, onSnapshot, doc, updateDoc, deleteDoc, orderBy, where, getDocs, getDoc, addDoc, serverTimestamp, increment } from 'firebase/firestore';
import { motion, AnimatePresence } from 'motion/react';
import { 
  ShieldCheck, 
  Search, 
  Filter, 
  Edit3, 
  Trash2, 
  Plane, 
  User, 
  Calendar, 
  MapPin, 
  CheckCircle2, 
  XCircle, 
  Clock,
  ArrowRight,
  Save,
  X
} from 'lucide-react';
import Navbar from '../components/Navbar';
import { handleFirestoreError, OperationType } from '../lib/firestore-utils';

interface BoardingPass {
  id: string;
  bookingId: string;
  userId: string;
  passengerName: string;
  destination: string;
  date: string;
  seatNumber: string;
  gate: string;
  class: string;
  status: 'active' | 'used' | 'cancelled';
  createdAt: any;
}

interface Booking {
  id: string;
  userId: string;
  userEmail: string;
  fullName: string;
  email?: string;
  passportNumber?: string;
  destination: string;
  date: string;
  status: 'pending' | 'paynow' | 'paid' | 'accepted' | 'completed' | 'cancelled';
  packagePrice?: number;
  price?: number;
  createdAt: any;
}

interface PersonalRequest {
  id: string;
  userId: string;
  userEmail: string;
  fullName: string;
  email?: string;
  passportNumber?: string;
  destination: string;
  date: string;
  status: 'pending' | 'paynow' | 'paid' | 'accepted' | 'completed' | 'cancelled';
  price?: number;
  createdAt: any;
}

const ADMIN_EMAIL = "ayashcselab@gmail.com";

export default function AdminPanel() {
  const navigate = useNavigate();
  const [activeTab, setActiveTab] = useState<'passes' | 'bookings' | 'requests'>('passes');
  const [passes, setPasses] = useState<BoardingPass[]>([]);
  const [bookings, setBookings] = useState<Booking[]>([]);
  const [requests, setRequests] = useState<PersonalRequest[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [filterStatus, setFilterStatus] = useState<string>('all');
  const [editingPass, setEditingPass] = useState<BoardingPass | null>(null);
  const [editingBooking, setEditingBooking] = useState<Booking | null>(null);
  const [editingRequest, setEditingRequest] = useState<PersonalRequest | null>(null);
  const [isSaving, setIsSaving] = useState(false);
  const [itemToDelete, setItemToDelete] = useState<{id: string, type: string} | null>(null);

  useEffect(() => {
    const unsubscribeAuth = auth.onAuthStateChanged((user) => {
      if (!user || user.email !== ADMIN_EMAIL) {
        navigate('/dashboard');
        return;
      }

      // Boarding Passes
      const qPasses = query(collection(db, 'boarding_passes'), orderBy('createdAt', 'desc'));
      const unsubscribePasses = onSnapshot(qPasses, (snapshot) => {
        setPasses(snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() })) as BoardingPass[]);
      });

      // Bookings
      const qBookings = query(collection(db, 'bookings'), orderBy('createdAt', 'desc'));
      const unsubscribeBookings = onSnapshot(qBookings, (snapshot) => {
        setBookings(snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() })) as Booking[]);
      });

      // Personal Requests
      const qRequests = query(collection(db, 'personal_requests'), orderBy('createdAt', 'desc'));
      const unsubscribeRequests = onSnapshot(qRequests, (snapshot) => {
        setRequests(snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() })) as PersonalRequest[]);
        setLoading(false);
      });

      return () => {
        unsubscribePasses();
        unsubscribeBookings();
        unsubscribeRequests();
      };
    });

    return () => unsubscribeAuth();
  }, [navigate]);

  const handleUpdateStatus = async (id: string, collectionName: string, newStatus: string) => {
    try {
      await updateDoc(doc(db, collectionName, id), { status: newStatus });
      
      // If status is set to 'cancelled', also cancel the boarding pass
      if (newStatus === 'cancelled') {
        const q = query(collection(db, 'boarding_passes'), where('bookingId', '==', id));
        const snapshot = await getDocs(q);
        snapshot.forEach(async (passDoc) => {
          await updateDoc(doc(db, 'boarding_passes', passDoc.id), { status: 'cancelled' });
        });
      }

      // If status is set to 'completed', award loyalty points
      if (newStatus === 'completed') {
        const docSnap = await getDoc(doc(db, collectionName, id));
        if (docSnap.exists()) {
          const data = docSnap.data();
          if (data.userId) {
            // Award 100 points per completed trip
            await updateDoc(doc(db, 'users', data.userId), {
              loyaltyPoints: increment(100)
            });
            
            // Send a notification about the points
            await addDoc(collection(db, 'notifications'), {
              userId: data.userId,
              message: `Congratulations! You've earned 100 loyalty points for completing your trip to ${data.destination}.`,
              type: 'payment_confirmed', // Reusing type for simplicity or add a new one
              read: false,
              createdAt: serverTimestamp()
            });
          }
        }
      }

      // If status is set to 'paid' or 'accepted', check if a boarding pass exists
      if (['paid', 'accepted'].includes(newStatus)) {
        const q = query(collection(db, 'boarding_passes'), where('bookingId', '==', id));
        const snapshot = await getDocs(q);
        
        if (snapshot.empty) {
          // Fetch the booking/request details
          const docSnap = await getDoc(doc(db, collectionName, id));
          if (docSnap.exists()) {
            const data = docSnap.data();
            // Create Boarding Pass automatically
            await addDoc(collection(db, 'boarding_passes'), {
              bookingId: id,
              userId: data.userId,
              passengerName: data.fullName || data.passengerName || 'Passenger',
              destination: data.destination,
              date: data.date,
              seatNumber: `${Math.floor(Math.random() * 30) + 1}${['A', 'B', 'C', 'D', 'E', 'F'][Math.floor(Math.random() * 6)]}`,
              gate: `G-${Math.floor(Math.random() * 50) + 1}`,
              class: 'Premium Economy',
              status: 'active',
              createdAt: serverTimestamp()
            });
          }
        }
      }
    } catch (error) {
      handleFirestoreError(error, OperationType.WRITE, `${collectionName}/${id}`);
    }
  };

  const handleDeleteItem = async () => {
    if (!itemToDelete) return;
    try {
      await deleteDoc(doc(db, itemToDelete.type, itemToDelete.id));
      setItemToDelete(null);
    } catch (error) {
      handleFirestoreError(error, OperationType.DELETE, `${itemToDelete.type}/${itemToDelete.id}`);
    }
  };

  const handleUpdatePass = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingPass) return;
    setIsSaving(true);
    try {
      await updateDoc(doc(db, 'boarding_passes', editingPass.id), {
        passengerName: editingPass.passengerName,
        destination: editingPass.destination,
        gate: editingPass.gate,
        seatNumber: editingPass.seatNumber,
        class: editingPass.class,
        status: editingPass.status
      });
      setEditingPass(null);
    } catch (error) {
      handleFirestoreError(error, OperationType.WRITE, `boarding_passes/${editingPass.id}`);
    } finally {
      setIsSaving(false);
    }
  };

  const handleUpdateBooking = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingBooking) return;
    setIsSaving(true);
    try {
      await updateDoc(doc(db, 'bookings', editingBooking.id), {
        fullName: editingBooking.fullName,
        email: editingBooking.email || '',
        passportNumber: editingBooking.passportNumber || '',
        destination: editingBooking.destination,
        date: editingBooking.date,
        status: editingBooking.status,
        price: editingBooking.price || 0
      });
      setEditingBooking(null);
    } catch (error) {
      handleFirestoreError(error, OperationType.WRITE, `bookings/${editingBooking.id}`);
    } finally {
      setIsSaving(false);
    }
  };

  const handleUpdateRequest = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingRequest) return;
    setIsSaving(true);
    try {
      await updateDoc(doc(db, 'personal_requests', editingRequest.id), {
        fullName: editingRequest.fullName,
        email: editingRequest.email || '',
        passportNumber: editingRequest.passportNumber || '',
        destination: editingRequest.destination,
        date: editingRequest.date,
        status: editingRequest.status,
        price: editingRequest.price || 0
      });
      setEditingRequest(null);
    } catch (error) {
      handleFirestoreError(error, OperationType.WRITE, `personal_requests/${editingRequest.id}`);
    } finally {
      setIsSaving(false);
    }
  };

  const filteredData = () => {
    if (activeTab === 'passes') {
      return passes.filter(p => 
        (p.passengerName.toLowerCase().includes(searchTerm.toLowerCase()) || p.destination.toLowerCase().includes(searchTerm.toLowerCase())) &&
        (filterStatus === 'all' || p.status === filterStatus)
      );
    } else if (activeTab === 'bookings') {
      return bookings.filter(b => 
        (b.fullName.toLowerCase().includes(searchTerm.toLowerCase()) || b.destination.toLowerCase().includes(searchTerm.toLowerCase())) &&
        (filterStatus === 'all' || b.status === filterStatus)
      );
    } else {
      return requests.filter(r => 
        (r.fullName.toLowerCase().includes(searchTerm.toLowerCase()) || r.destination.toLowerCase().includes(searchTerm.toLowerCase())) &&
        (filterStatus === 'all' || r.status === filterStatus)
      );
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-[#121212] flex items-center justify-center">
        <div className="w-12 h-12 border-4 border-[#7371ff]/20 border-t-[#7371ff] rounded-full animate-spin" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#121212] text-white selection:bg-[#7371ff] selection:text-white">
      <Navbar />
      
      <div className="pt-32 pb-20 px-4 md:px-8 max-w-7xl mx-auto">
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 mb-12">
          <div className="space-y-2">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-[#7371ff]/10 rounded-xl flex items-center justify-center border border-[#7371ff]/20">
                <ShieldCheck className="w-6 h-6 text-[#7371ff]" />
              </div>
              <h1 className="text-4xl font-black tracking-tighter uppercase">Admin Panel</h1>
            </div>
            <p className="text-white/40 font-bold uppercase tracking-widest text-xs">Manage and edit all boarding passes</p>
          </div>

          <div className="flex flex-wrap items-center gap-4">
            <div className="flex bg-white/5 p-1 rounded-2xl border border-white/10">
              <button 
                onClick={() => setActiveTab('passes')}
                className={`px-6 py-2 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all ${activeTab === 'passes' ? 'bg-[#7371ff] text-white' : 'text-white/40 hover:text-white'}`}
              >
                Passes
              </button>
              <button 
                onClick={() => setActiveTab('bookings')}
                className={`px-6 py-2 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all ${activeTab === 'bookings' ? 'bg-[#7371ff] text-white' : 'text-white/40 hover:text-white'}`}
              >
                Bookings
              </button>
              <button 
                onClick={() => setActiveTab('requests')}
                className={`px-6 py-2 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all ${activeTab === 'requests' ? 'bg-[#7371ff] text-white' : 'text-white/40 hover:text-white'}`}
              >
                Requests
              </button>
            </div>
            <div className="relative group">
              <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-white/20 group-focus-within:text-[#7371ff] transition-colors" />
              <input 
                type="text" 
                placeholder={`Search ${activeTab}...`}
                className="bg-white/5 border border-white/10 rounded-2xl pl-12 pr-6 py-3 text-sm outline-none focus:ring-2 focus:ring-[#7371ff]/50 transition-all w-full md:w-64"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
              />
            </div>
            <div className="flex items-center gap-2 bg-white/5 border border-white/10 rounded-2xl px-4 py-3">
              <Filter className="w-4 h-4 text-white/20" />
              <select 
                className="bg-transparent outline-none text-sm font-bold uppercase tracking-widest cursor-pointer"
                value={filterStatus}
                onChange={(e) => setFilterStatus(e.target.value)}
              >
                <option value="all" className="bg-slate-900">All Status</option>
                {activeTab === 'passes' ? (
                  <>
                    <option value="active" className="bg-slate-900">Active</option>
                    <option value="used" className="bg-slate-900">Used</option>
                    <option value="cancelled" className="bg-slate-900">Cancelled</option>
                  </>
                ) : (
                  <>
                    <option value="pending" className="bg-slate-900">Pending</option>
                    <option value="paid" className="bg-slate-900">Paid</option>
                    <option value="accepted" className="bg-slate-900">Accepted</option>
                    <option value="completed" className="bg-slate-900">Completed</option>
                    <option value="cancelled" className="bg-slate-900">Cancelled</option>
                  </>
                )}
              </select>
            </div>
          </div>
        </div>

        {/* Data Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-2 xl:grid-cols-3 gap-6">
          <AnimatePresence mode="popLayout">
            {filteredData().map((item: any) => (
              <motion.div
                key={item.id}
                layout
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.9 }}
                className="bg-white/5 border border-white/10 rounded-[32px] p-6 space-y-6 hover:bg-white/[0.07] transition-all group"
              >
                <div className="flex justify-between items-start">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-xl bg-[#7371ff]/10 flex items-center justify-center border border-[#7371ff]/20">
                      {activeTab === 'passes' ? <Plane className="w-5 h-5 text-[#7371ff]" /> : <User className="w-5 h-5 text-[#7371ff]" />}
                    </div>
                    <div>
                      <p className="text-[10px] font-black text-white/40 uppercase tracking-widest">{activeTab === 'passes' ? 'Booking ID' : 'User Email'}</p>
                      <p className="font-mono font-bold text-xs uppercase truncate max-w-[120px]">
                        {activeTab === 'passes' ? item.bookingId : item.userEmail}
                      </p>
                    </div>
                  </div>
                  <div className={`px-3 py-1 rounded-full text-[10px] font-black uppercase tracking-widest border ${
                    ['active', 'accepted', 'completed'].includes(item.status) ? 'bg-green-500/10 text-green-400 border-green-500/20' :
                    item.status === 'paid' ? 'bg-blue-500/10 text-blue-400 border-blue-500/20' :
                    item.status === 'cancelled' ? 'bg-red-500/10 text-red-400 border-red-500/20' :
                    'bg-amber-500/10 text-amber-400 border-amber-500/20'
                  }`}>
                    {item.status}
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-1">
                    <p className="text-[10px] font-black text-white/40 uppercase tracking-widest flex items-center gap-1.5">
                      <User className="w-3 h-3" /> {activeTab === 'passes' ? 'Passenger' : 'Full Name'}
                    </p>
                    <p className="font-bold text-sm truncate">{activeTab === 'passes' ? item.passengerName : item.fullName}</p>
                  </div>
                  <div className="space-y-1">
                    <p className="text-[10px] font-black text-white/40 uppercase tracking-widest flex items-center gap-1.5">
                      <MapPin className="w-3 h-3" /> Destination
                    </p>
                    <p className="font-bold text-sm truncate">{item.destination}</p>
                  </div>
                  <div className="space-y-1">
                    <p className="text-[10px] font-black text-white/40 uppercase tracking-widest flex items-center gap-1.5">
                      <Calendar className="w-3 h-3" /> Date
                    </p>
                    <p className="font-bold text-sm">{item.date}</p>
                  </div>
                  {activeTab === 'passes' && (
                    <div className="space-y-1">
                      <p className="text-[10px] font-black text-white/40 uppercase tracking-widest flex items-center gap-1.5">
                        <Clock className="w-3 h-3" /> Gate/Seat
                      </p>
                      <p className="font-bold text-sm">{item.gate} / {item.seatNumber}</p>
                    </div>
                  )}
                </div>

                <div className="pt-6 border-t border-white/5 flex flex-wrap items-center gap-3">
                  {activeTab === 'passes' ? (
                    <button 
                      onClick={() => setEditingPass(item)}
                      className="flex-1 py-3 bg-white/5 hover:bg-white/10 rounded-xl font-black uppercase tracking-widest text-[10px] transition-all flex items-center justify-center gap-2 border border-white/10"
                    >
                      <Edit3 className="w-3 h-3" /> Edit Pass
                    </button>
                  ) : (
                    <div className="flex flex-wrap gap-2 w-full">
                      <button 
                        onClick={() => activeTab === 'bookings' ? setEditingBooking(item) : setEditingRequest(item)}
                        className="flex-1 py-3 bg-white/5 hover:bg-white/10 rounded-xl font-black uppercase tracking-widest text-[10px] transition-all flex items-center justify-center gap-2 border border-white/10"
                      >
                        <Edit3 className="w-3 h-3" /> Edit {activeTab === 'bookings' ? 'Booking' : 'Request'}
                      </button>
                      <select 
                        className="flex-1 bg-white/5 border border-white/10 rounded-xl px-4 py-2 text-[10px] font-black uppercase tracking-widest outline-none focus:ring-1 focus:ring-[#7371ff]"
                        value={item.status}
                        onChange={(e) => handleUpdateStatus(item.id, activeTab === 'bookings' ? 'bookings' : 'personal_requests', e.target.value)}
                      >
                        <option value="pending">Pending</option>
                        <option value="paynow">Pay Now</option>
                        <option value="paid">Paid</option>
                        <option value="accepted">Accepted</option>
                        <option value="completed">Completed</option>
                        <option value="cancelled">Cancelled</option>
                      </select>
                    </div>
                  )}
                  <button 
                    onClick={() => setItemToDelete({id: item.id, type: activeTab === 'passes' ? 'boarding_passes' : (activeTab === 'bookings' ? 'bookings' : 'personal_requests')})}
                    className="w-10 h-10 bg-red-500/10 hover:bg-red-500/20 text-red-400 rounded-xl transition-all flex items-center justify-center border border-red-500/20"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </motion.div>
            ))}
          </AnimatePresence>
        </div>

        {filteredData().length === 0 && (
          <div className="py-20 text-center space-y-4">
            <Plane className="w-16 h-16 text-white/5 mx-auto" />
            <p className="text-white/20 font-black uppercase tracking-widest">No {activeTab} found</p>
          </div>
        )}
      </div>

      {/* Delete Confirmation Modal */}
      <AnimatePresence>
        {itemToDelete && (
          <div className="fixed inset-0 z-[300] flex items-center justify-center p-4">
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setItemToDelete(null)}
              className="absolute inset-0 bg-black/90 backdrop-blur-md"
            />
            <motion.div
              initial={{ opacity: 0, scale: 0.95, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 20 }}
              className="relative w-full max-w-md bg-slate-900 border border-white/10 rounded-[40px] shadow-2xl p-8 text-center space-y-6"
            >
              <div className="w-20 h-20 bg-red-500/10 rounded-[32px] flex items-center justify-center mx-auto border border-red-500/20">
                <Trash2 className="w-10 h-10 text-red-500" />
              </div>
              <div className="space-y-2">
                <h3 className="text-2xl font-black uppercase tracking-tight">Delete Item?</h3>
                <p className="text-white/40 font-bold uppercase tracking-widest text-[10px] leading-relaxed">
                  This action is permanent and cannot be undone.
                </p>
              </div>
              <div className="flex gap-4 pt-4">
                <button
                  onClick={() => setItemToDelete(null)}
                  className="flex-1 py-5 bg-white/5 hover:bg-white/10 rounded-2xl font-black uppercase tracking-widest text-xs transition-all"
                >
                  Cancel
                </button>
                <button
                  onClick={handleDeleteItem}
                  className="flex-1 py-5 bg-red-500 hover:bg-red-600 rounded-2xl font-black uppercase tracking-widest text-xs transition-all shadow-2xl shadow-red-500/20"
                >
                  Delete Now
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Edit Booking Modal */}
      <AnimatePresence>
        {editingBooking && (
          <div className="fixed inset-0 z-[200] flex items-center justify-center p-4">
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setEditingBooking(null)}
              className="absolute inset-0 bg-black/80 backdrop-blur-sm"
            />
            <motion.div
              initial={{ opacity: 0, scale: 0.95, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 20 }}
              className="relative w-full max-w-xl bg-slate-900 border border-white/10 rounded-[40px] shadow-2xl overflow-hidden"
            >
              <div className="p-8 border-b border-white/5 flex items-center justify-between bg-white/5">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 bg-[#7371ff]/10 rounded-xl flex items-center justify-center border border-[#7371ff]/20">
                    <Edit3 className="w-5 h-5 text-[#7371ff]" />
                  </div>
                  <div>
                    <h3 className="text-xl font-black uppercase tracking-tight">Edit Booking</h3>
                    <p className="text-[10px] font-black text-white/40 uppercase tracking-widest">ID: {editingBooking.id}</p>
                  </div>
                </div>
                <button 
                  onClick={() => setEditingBooking(null)}
                  className="w-10 h-10 rounded-full bg-white/5 flex items-center justify-center hover:bg-white/10 transition-colors"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              <form onSubmit={handleUpdateBooking} className="p-8 space-y-6">
                <div className="grid grid-cols-2 gap-6">
                  <div className="space-y-2">
                    <label className="text-[10px] font-black uppercase tracking-[0.2em] text-white/40 ml-2">Full Name</label>
                    <input 
                      type="text" 
                      required
                      className="w-full bg-white/5 border border-white/10 rounded-2xl px-6 py-4 text-white outline-none focus:ring-2 focus:ring-[#7371ff]/50 transition-all"
                      value={editingBooking.fullName}
                      onChange={(e) => setEditingBooking({...editingBooking, fullName: e.target.value})}
                    />
                  </div>
                  <div className="space-y-2">
                    <label className="text-[10px] font-black uppercase tracking-[0.2em] text-white/40 ml-2">Gmail</label>
                    <input 
                      type="email" 
                      required
                      pattern=".+@gmail\.com"
                      title="Please enter a valid Gmail address (e.g., user@gmail.com)"
                      className="w-full bg-white/5 border border-white/10 rounded-2xl px-6 py-4 text-white outline-none focus:ring-2 focus:ring-[#7371ff]/50 transition-all"
                      value={editingBooking.email || ''}
                      onChange={(e) => setEditingBooking({...editingBooking, email: e.target.value})}
                    />
                  </div>
                  <div className="space-y-2">
                    <label className="text-[10px] font-black uppercase tracking-[0.2em] text-white/40 ml-2">Passport Number</label>
                    <input 
                      type="text" 
                      required
                      className="w-full bg-white/5 border border-white/10 rounded-2xl px-6 py-4 text-white outline-none focus:ring-2 focus:ring-[#7371ff]/50 transition-all"
                      value={editingBooking.passportNumber || ''}
                      onChange={(e) => {
                        const value = e.target.value.replace(/[^0-9]/g, '');
                        setEditingBooking({...editingBooking, passportNumber: value});
                      }}
                    />
                  </div>
                  <div className="space-y-2">
                    <label className="text-[10px] font-black uppercase tracking-[0.2em] text-white/40 ml-2">Destination</label>
                    <input 
                      type="text" 
                      required
                      className="w-full bg-white/5 border border-white/10 rounded-2xl px-6 py-4 text-white outline-none focus:ring-2 focus:ring-[#7371ff]/50 transition-all"
                      value={editingBooking.destination}
                      onChange={(e) => setEditingBooking({...editingBooking, destination: e.target.value})}
                    />
                  </div>
                  <div className="space-y-2">
                    <label className="text-[10px] font-black uppercase tracking-[0.2em] text-white/40 ml-2">Date</label>
                    <input 
                      type="date" 
                      required
                      className="w-full bg-white/5 border border-white/10 rounded-2xl px-6 py-4 text-white outline-none focus:ring-2 focus:ring-[#7371ff]/50 transition-all"
                      value={editingBooking.date}
                      onChange={(e) => setEditingBooking({...editingBooking, date: e.target.value})}
                    />
                  </div>
                  <div className="space-y-2">
                    <label className="text-[10px] font-black uppercase tracking-[0.2em] text-white/40 ml-2">Status</label>
                    <select 
                      className="w-full bg-white/5 border border-white/10 rounded-2xl px-6 py-4 text-white outline-none focus:ring-2 focus:ring-[#7371ff]/50 transition-all"
                      value={editingBooking.status}
                      onChange={(e) => setEditingBooking({...editingBooking, status: e.target.value as any})}
                    >
                      <option value="pending" className="bg-slate-900">Pending</option>
                      <option value="paynow" className="bg-slate-900">Pay Now</option>
                      <option value="paid" className="bg-slate-900">Paid</option>
                      <option value="accepted" className="bg-slate-900">Accepted</option>
                      <option value="completed" className="bg-slate-900">Completed</option>
                      <option value="cancelled" className="bg-slate-900">Cancelled</option>
                    </select>
                  </div>
                  <div className="space-y-2">
                    <label className="text-[10px] font-black uppercase tracking-[0.2em] text-white/40 ml-2">Price ($)</label>
                    <input 
                      type="number" 
                      className="w-full bg-white/5 border border-white/10 rounded-2xl px-6 py-4 text-white outline-none focus:ring-2 focus:ring-[#7371ff]/50 transition-all"
                      value={editingBooking.price || ''}
                      onChange={(e) => setEditingBooking({...editingBooking, price: Number(e.target.value)})}
                      placeholder="Enter price..."
                    />
                  </div>
                </div>

                <div className="flex gap-4 pt-4">
                  <button
                    type="button"
                    onClick={() => setEditingBooking(null)}
                    className="flex-1 py-5 bg-white/5 hover:bg-white/10 rounded-2xl font-black uppercase tracking-widest text-xs transition-all"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    disabled={isSaving}
                    className="flex-1 py-5 bg-[#7371ff] hover:bg-[#6361ff] rounded-2xl font-black uppercase tracking-widest text-xs transition-all shadow-2xl shadow-[#7371ff]/20 flex items-center justify-center gap-2 disabled:opacity-70"
                  >
                    {isSaving ? (
                      <>
                        <div className="w-4 h-4 border-2 border-white/20 border-t-white rounded-full animate-spin" />
                        Saving...
                      </>
                    ) : (
                      <>
                        <Save className="w-4 h-4" /> Save Changes
                      </>
                    )}
                  </button>
                </div>
              </form>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Edit Request Modal */}
      <AnimatePresence>
        {editingRequest && (
          <div className="fixed inset-0 z-[200] flex items-center justify-center p-4">
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setEditingRequest(null)}
              className="absolute inset-0 bg-black/80 backdrop-blur-sm"
            />
            <motion.div
              initial={{ opacity: 0, scale: 0.95, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 20 }}
              className="relative w-full max-w-xl bg-slate-900 border border-white/10 rounded-[40px] shadow-2xl overflow-hidden"
            >
              <div className="p-8 border-b border-white/5 flex items-center justify-between bg-white/5">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 bg-[#7371ff]/10 rounded-xl flex items-center justify-center border border-[#7371ff]/20">
                    <Edit3 className="w-5 h-5 text-[#7371ff]" />
                  </div>
                  <div>
                    <h3 className="text-xl font-black uppercase tracking-tight">Edit Personal Request</h3>
                    <p className="text-[10px] font-black text-white/40 uppercase tracking-widest">ID: {editingRequest.id}</p>
                  </div>
                </div>
                <button 
                  onClick={() => setEditingRequest(null)}
                  className="w-10 h-10 rounded-full bg-white/5 flex items-center justify-center hover:bg-white/10 transition-colors"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              <form onSubmit={handleUpdateRequest} className="p-8 space-y-6">
                <div className="grid grid-cols-2 gap-6">
                  <div className="space-y-2">
                    <label className="text-[10px] font-black uppercase tracking-[0.2em] text-white/40 ml-2">Full Name</label>
                    <input 
                      type="text" 
                      required
                      className="w-full bg-white/5 border border-white/10 rounded-2xl px-6 py-4 text-white outline-none focus:ring-2 focus:ring-[#7371ff]/50 transition-all"
                      value={editingRequest.fullName}
                      onChange={(e) => setEditingRequest({...editingRequest, fullName: e.target.value})}
                    />
                  </div>
                  <div className="space-y-2">
                    <label className="text-[10px] font-black uppercase tracking-[0.2em] text-white/40 ml-2">Gmail</label>
                    <input 
                      type="email" 
                      required
                      pattern=".+@gmail\.com"
                      title="Please enter a valid Gmail address (e.g., user@gmail.com)"
                      className="w-full bg-white/5 border border-white/10 rounded-2xl px-6 py-4 text-white outline-none focus:ring-2 focus:ring-[#7371ff]/50 transition-all"
                      value={editingRequest.email || ''}
                      onChange={(e) => setEditingRequest({...editingRequest, email: e.target.value})}
                    />
                  </div>
                  <div className="space-y-2">
                    <label className="text-[10px] font-black uppercase tracking-[0.2em] text-white/40 ml-2">Passport Number</label>
                    <input 
                      type="text" 
                      required
                      className="w-full bg-white/5 border border-white/10 rounded-2xl px-6 py-4 text-white outline-none focus:ring-2 focus:ring-[#7371ff]/50 transition-all"
                      value={editingRequest.passportNumber || ''}
                      onChange={(e) => {
                        const value = e.target.value.replace(/[^0-9]/g, '');
                        setEditingRequest({...editingRequest, passportNumber: value});
                      }}
                    />
                  </div>
                  <div className="space-y-2">
                    <label className="text-[10px] font-black uppercase tracking-[0.2em] text-white/40 ml-2">Destination</label>
                    <input 
                      type="text" 
                      required
                      className="w-full bg-white/5 border border-white/10 rounded-2xl px-6 py-4 text-white outline-none focus:ring-2 focus:ring-[#7371ff]/50 transition-all"
                      value={editingRequest.destination}
                      onChange={(e) => setEditingRequest({...editingRequest, destination: e.target.value})}
                    />
                  </div>
                  <div className="space-y-2">
                    <label className="text-[10px] font-black uppercase tracking-[0.2em] text-white/40 ml-2">Date</label>
                    <input 
                      type="date" 
                      required
                      className="w-full bg-white/5 border border-white/10 rounded-2xl px-6 py-4 text-white outline-none focus:ring-2 focus:ring-[#7371ff]/50 transition-all"
                      value={editingRequest.date}
                      onChange={(e) => setEditingRequest({...editingRequest, date: e.target.value})}
                    />
                  </div>
                  <div className="space-y-2">
                    <label className="text-[10px] font-black uppercase tracking-[0.2em] text-white/40 ml-2">Price ($)</label>
                    <input 
                      type="number" 
                      className="w-full bg-white/5 border border-white/10 rounded-2xl px-6 py-4 text-white outline-none focus:ring-2 focus:ring-[#7371ff]/50 transition-all"
                      value={editingRequest.price || ''}
                      onChange={(e) => setEditingRequest({...editingRequest, price: Number(e.target.value)})}
                    />
                  </div>
                  <div className="space-y-2">
                    <label className="text-[10px] font-black uppercase tracking-[0.2em] text-white/40 ml-2">Status</label>
                    <select 
                      className="w-full bg-white/5 border border-white/10 rounded-2xl px-6 py-4 text-white outline-none focus:ring-2 focus:ring-[#7371ff]/50 transition-all"
                      value={editingRequest.status}
                      onChange={(e) => setEditingRequest({...editingRequest, status: e.target.value as any})}
                    >
                      <option value="pending" className="bg-slate-900">Pending</option>
                      <option value="paynow" className="bg-slate-900">Pay Now</option>
                      <option value="paid" className="bg-slate-900">Paid</option>
                      <option value="accepted" className="bg-slate-900">Accepted</option>
                      <option value="completed" className="bg-slate-900">Completed</option>
                      <option value="cancelled" className="bg-slate-900">Cancelled</option>
                    </select>
                  </div>
                </div>

                <div className="flex gap-4 pt-4">
                  <button
                    type="button"
                    onClick={() => setEditingRequest(null)}
                    className="flex-1 py-5 bg-white/5 hover:bg-white/10 rounded-2xl font-black uppercase tracking-widest text-xs transition-all"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    disabled={isSaving}
                    className="flex-1 py-5 bg-[#7371ff] hover:bg-[#6361ff] rounded-2xl font-black uppercase tracking-widest text-xs transition-all shadow-2xl shadow-[#7371ff]/20 flex items-center justify-center gap-2 disabled:opacity-70"
                  >
                    {isSaving ? (
                      <>
                        <div className="w-4 h-4 border-2 border-white/20 border-t-white rounded-full animate-spin" />
                        Saving...
                      </>
                    ) : (
                      <>
                        <Save className="w-4 h-4" /> Save Changes
                      </>
                    )}
                  </button>
                </div>
              </form>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Edit Pass Modal */}
      <AnimatePresence>
        {editingPass && (
          <div className="fixed inset-0 z-[200] flex items-center justify-center p-4">
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setEditingPass(null)}
              className="absolute inset-0 bg-black/80 backdrop-blur-sm"
            />
            <motion.div
              initial={{ opacity: 0, scale: 0.95, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 20 }}
              className="relative w-full max-w-xl bg-slate-900 border border-white/10 rounded-[40px] shadow-2xl overflow-hidden"
            >
              <div className="p-8 border-b border-white/5 flex items-center justify-between bg-white/5">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 bg-[#7371ff]/10 rounded-xl flex items-center justify-center border border-[#7371ff]/20">
                    <Edit3 className="w-5 h-5 text-[#7371ff]" />
                  </div>
                  <div>
                    <h3 className="text-xl font-black uppercase tracking-tight">Edit Boarding Pass</h3>
                    <p className="text-[10px] font-black text-white/40 uppercase tracking-widest">ID: {editingPass.id}</p>
                  </div>
                </div>
                <button 
                  onClick={() => setEditingPass(null)}
                  className="w-10 h-10 rounded-full bg-white/5 flex items-center justify-center hover:bg-white/10 transition-colors"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              <form onSubmit={handleUpdatePass} className="p-8 space-y-6">
                <div className="grid grid-cols-2 gap-6">
                  <div className="space-y-2">
                    <label className="text-[10px] font-black uppercase tracking-[0.2em] text-white/40 ml-2">Passenger Name</label>
                    <input 
                      type="text" 
                      required
                      className="w-full bg-white/5 border border-white/10 rounded-2xl px-6 py-4 text-white outline-none focus:ring-2 focus:ring-[#7371ff]/50 transition-all"
                      value={editingPass.passengerName}
                      onChange={(e) => setEditingPass({...editingPass, passengerName: e.target.value})}
                    />
                  </div>
                  <div className="space-y-2">
                    <label className="text-[10px] font-black uppercase tracking-[0.2em] text-white/40 ml-2">Destination</label>
                    <input 
                      type="text" 
                      required
                      className="w-full bg-white/5 border border-white/10 rounded-2xl px-6 py-4 text-white outline-none focus:ring-2 focus:ring-[#7371ff]/50 transition-all"
                      value={editingPass.destination}
                      onChange={(e) => setEditingPass({...editingPass, destination: e.target.value})}
                    />
                  </div>
                  <div className="space-y-2">
                    <label className="text-[10px] font-black uppercase tracking-[0.2em] text-white/40 ml-2">Gate</label>
                    <input 
                      type="text" 
                      required
                      className="w-full bg-white/5 border border-white/10 rounded-2xl px-6 py-4 text-white outline-none focus:ring-2 focus:ring-[#7371ff]/50 transition-all"
                      value={editingPass.gate}
                      onChange={(e) => setEditingPass({...editingPass, gate: e.target.value})}
                    />
                  </div>
                  <div className="space-y-2">
                    <label className="text-[10px] font-black uppercase tracking-[0.2em] text-white/40 ml-2">Seat Number</label>
                    <input 
                      type="text" 
                      required
                      className="w-full bg-white/5 border border-white/10 rounded-2xl px-6 py-4 text-white outline-none focus:ring-2 focus:ring-[#7371ff]/50 transition-all"
                      value={editingPass.seatNumber}
                      onChange={(e) => setEditingPass({...editingPass, seatNumber: e.target.value})}
                    />
                  </div>
                  <div className="space-y-2">
                    <label className="text-[10px] font-black uppercase tracking-[0.2em] text-white/40 ml-2">Class</label>
                    <input 
                      type="text" 
                      required
                      className="w-full bg-white/5 border border-white/10 rounded-2xl px-6 py-4 text-white outline-none focus:ring-2 focus:ring-[#7371ff]/50 transition-all"
                      value={editingPass.class}
                      onChange={(e) => setEditingPass({...editingPass, class: e.target.value})}
                    />
                  </div>
                  <div className="space-y-2">
                    <label className="text-[10px] font-black uppercase tracking-[0.2em] text-white/40 ml-2">Status</label>
                    <select 
                      className="w-full bg-white/5 border border-white/10 rounded-2xl px-6 py-4 text-white outline-none focus:ring-2 focus:ring-[#7371ff]/50 transition-all"
                      value={editingPass.status}
                      onChange={(e) => setEditingPass({...editingPass, status: e.target.value as any})}
                    >
                      <option value="active" className="bg-slate-900">Active</option>
                      <option value="used" className="bg-slate-900">Used</option>
                      <option value="cancelled" className="bg-slate-900">Cancelled</option>
                    </select>
                  </div>
                </div>

                <div className="flex gap-4 pt-4">
                  <button
                    type="button"
                    onClick={() => setEditingPass(null)}
                    className="flex-1 py-5 bg-white/5 hover:bg-white/10 rounded-2xl font-black uppercase tracking-widest text-xs transition-all"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    disabled={isSaving}
                    className="flex-1 py-5 bg-[#7371ff] hover:bg-[#6361ff] rounded-2xl font-black uppercase tracking-widest text-xs transition-all shadow-2xl shadow-[#7371ff]/20 flex items-center justify-center gap-2 disabled:opacity-70"
                  >
                    {isSaving ? (
                      <>
                        <div className="w-4 h-4 border-2 border-white/20 border-t-white rounded-full animate-spin" />
                        Saving...
                      </>
                    ) : (
                      <>
                        <Save className="w-4 h-4" /> Save Changes
                      </>
                    )}
                  </button>
                </div>
              </form>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}
